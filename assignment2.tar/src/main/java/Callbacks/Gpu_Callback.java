package Callbacks;

import bgu.spl.mics.Callback;

public interface Gpu_Callback {
    public void call();
}
